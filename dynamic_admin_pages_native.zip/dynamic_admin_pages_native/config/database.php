<?php
  $hostname = 'localhost';
  $username = 'root';
  $password = '';
  $database = 'login-lengkap-native';
  $connect = mysqli_connect($hostname,$username,$password,$database);

  function query($query)
  {
    global $connect;
    $result = mysqli_query($connect,$query);
    $rows = [];
    while ($row=mysqli_fetch_assoc($result)) {
      $rows[] = $row;
    }
    return $rows;
  }
