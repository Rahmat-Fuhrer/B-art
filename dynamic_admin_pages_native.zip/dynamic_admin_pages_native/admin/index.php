<?php
  require "../config/database.php";
  require "../layouts/header.php";
  require "../layouts/sidebar.php";
  require "../layouts/topbar.php";


  if (isset($_GET['action'])) {
    if (isset($_GET['iduser'])) {
    switch ($_GET['action']) {
      case 'hapus':
        mysqli_query($connect,"DELETE FROM user WHERE iduser='$_GET[iduser]'");
        break;
      default:
        header('location:index.php');
        break;
      }
    }
  }



  if (isset($_GET['page'])) {
    switch($_GET['page']){
      case 'profile':
        include "profile.php";
      break;
      case 'tables':
        include "tables.php";
      break;
      case 'dashboard':
        include 'dashboard.php';
      break;
      default :
        include "notfound.php";
      break;
    }
  }else{
    include "admin.php";
  }
  require "../layouts/footer.php";
?>
