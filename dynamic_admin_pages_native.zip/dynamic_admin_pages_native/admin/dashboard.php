<?php
  $users = query("SELECT * FROM user");
 ?>
<!-- Begin Page Content -->
<div class="container-fluid">
<!-- Page Heading -->
<h1 class="h3 mb-4 text-gray-800">Dashboard</h1>

<table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">First</th>
      <th scope="col">Last</th>
      <th scope="col">Other</th>
      <th scope="col">Handle</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($users as $user): ?>
      <tr>
        <th scope="row">#</th>
        <td><?= $user['username']; ?></td>
        <td><?= $user['email']; ?></td>
        <td><?= $user['role_id']; ?></td>
        <td><a href="index.php?action=hapus&iduser=<?= $user['iduser']; ?>">Hapus</a></td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>

</div>

<!-- /.container-fluid -->
